<?php
if (isset($_GET['acao'])) {
    $acao = $_GET['acao'];
}else{
    $acao = 'index';
}
require "app/model/CategoriaCrud.php";

switch ($acao){
    case 'index':

    $crud = new CategoriaCrud();
    $categorias = $crud-> getCategorias;

    include 'app/view/principal/index.html';
    break;
}